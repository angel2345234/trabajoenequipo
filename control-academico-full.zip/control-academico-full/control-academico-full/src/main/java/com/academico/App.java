package com.academico;

import com.academico.ui.VentanaLogin;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class App {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // (Opcional) Look & Feel del sistema
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}

            // Iniciar en la pantalla de Login
            new VentanaLogin().setVisible(true);
        });
    }
}
