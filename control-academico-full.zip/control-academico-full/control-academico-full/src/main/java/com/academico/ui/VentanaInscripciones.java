package com.academico.ui;

import com.academico.dao.AlumnoDAO;
import com.academico.dao.CursoDAO;
import com.academico.dao.InscripcionDAO;
import com.academico.modelo.Curso;
import com.academico.modelo.Alumno;
import com.academico.modelo.InscripcionVista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class VentanaInscripciones extends JFrame {
    private final JComboBox<ComboItem> cbAlumno = new JComboBox<>();
    private final JComboBox<ComboItem> cbCurso  = new JComboBox<>();
    private final JTextField txtNota = new JTextField(6);

    private final JButton btnInscribir   = new JButton("Inscribir");
    private final JButton btnActualizar  = new JButton("Actualizar nota");
    private final JButton btnEliminar    = new JButton("Eliminar");
    private final JButton btnRefrescar   = new JButton("Refrescar");

    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID", "Alumno", "Curso", "Nota"}, 0) {
        @Override public boolean isCellEditable(int row, int col) { return false; }
    };
    private final JTable tabla = new JTable(model);

    public VentanaInscripciones() {
        setTitle("Inscripciones");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Top panel (combos + Nota)
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        top.add(new JLabel("Alumno:")); top.add(cbAlumno);
        top.add(new JLabel("Curso:"));  top.add(cbCurso);
        top.add(new JLabel("Nota (0-20):")); top.add(txtNota);
        top.add(btnInscribir); top.add(btnActualizar); top.add(btnEliminar); top.add(btnRefrescar);

        // Tabla
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setPreferredSize(new Dimension(640, 240));

        setLayout(new BorderLayout());
        add(top, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        // Eventos
        btnInscribir.addActionListener(e -> inscribir());
        btnActualizar.addActionListener(e -> actualizarNotaSeleccionada());
        btnEliminar.addActionListener(e -> eliminarSeleccionada());
        btnRefrescar.addActionListener(e -> cargarTabla());

        // Carga inicial combos y tabla
        cargarCombos();
        cargarTabla();

        pack();
    }

    private void cargarCombos() {
        cbAlumno.removeAllItems();
        cbCurso.removeAllItems();
        try {
            List<Alumno> alumnos = new AlumnoDAO().listar(); // ya tienes listar()
            for (Alumno a : alumnos) {
                cbAlumno.addItem(new ComboItem(a.getId(), a.getNombre()));
            }
            List<Curso> cursos = new CursoDAO().listar();
            for (Curso c : cursos) {
                cbCurso.addItem(new ComboItem(c.getId(), c.getNombre()));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar combos: " + e.getMessage());
        }
    }

    private void cargarTabla() {
        model.setRowCount(0);
        try {
            for (InscripcionVista v : new InscripcionDAO().listarVistas()) {
                model.addRow(new Object[]{v.getId(), v.getAlumno(), v.getCurso(),
                        v.getNota() == null ? "" : v.getNota().toString()});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al listar: " + e.getMessage());
        }
    }

    private void inscribir() {
        ComboItem selAlu = (ComboItem) cbAlumno.getSelectedItem();
        ComboItem selCur = (ComboItem) cbCurso.getSelectedItem();
        if (selAlu == null || selCur == null) {
            JOptionPane.showMessageDialog(this, "Selecciona alumno y curso.");
            return;
        }
        BigDecimal nota = null;
        String t = txtNota.getText().trim();
        if (!t.isEmpty()) {
            try {
                nota = new BigDecimal(t);
                if (nota.compareTo(BigDecimal.ZERO) < 0 || nota.compareTo(new BigDecimal("20")) > 0) {
                    JOptionPane.showMessageDialog(this, "La nota debe estar entre 0 y 20.");
                    return;
                }
            } catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(this, "Nota inválida.");
                return;
            }
        }
        try {
            new InscripcionDAO().registrar(selAlu.getId(), selCur.getId(), nota);
            JOptionPane.showMessageDialog(this, "Inscripción creada.");
            txtNota.setText("");
            cargarTabla();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al inscribir: " + e.getMessage());
        }
    }

    private void actualizarNotaSeleccionada() {
        int row = tabla.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Selecciona una inscripción."); return; }

        int id = (int) model.getValueAt(row, 0);
        String s = JOptionPane.showInputDialog(this, "Nueva nota (0-20):", model.getValueAt(row, 3));
        if (s == null) return; // cancelado
        try {
            BigDecimal n = new BigDecimal(s.trim());
            if (n.compareTo(BigDecimal.ZERO) < 0 || n.compareTo(new BigDecimal("20")) > 0) {
                JOptionPane.showMessageDialog(this, "La nota debe estar entre 0 y 20.");
                return;
            }
            new InscripcionDAO().actualizarNota(id, n);
            cargarTabla();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Nota inválida.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al actualizar: " + e.getMessage());
        }
    }

    private void eliminarSeleccionada() {
        int row = tabla.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Selecciona una inscripción."); return; }
        int id = (int) model.getValueAt(row, 0);
        int r = JOptionPane.showConfirmDialog(this, "¿Eliminar inscripción?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (r != JOptionPane.YES_OPTION) return;
        try {
            new InscripcionDAO().eliminar(id);
            cargarTabla();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al eliminar: " + e.getMessage());
        }
    }
}
