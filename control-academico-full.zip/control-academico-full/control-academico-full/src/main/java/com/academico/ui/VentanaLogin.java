package com.academico.ui;

import com.academico.dao.UsuarioDAO;
import com.academico.modelo.Usuario;
import com.academico.util.PasswordUtil;

import javax.swing.*;
import java.awt.*;

public class VentanaLogin extends JFrame {
    private final JTextField txtUsuario = new JTextField(18);
    private final JPasswordField txtContrasena = new JPasswordField(18);
    private final JButton btnIngresar = new JButton("Ingresar");

    public VentanaLogin() {
        setTitle("Login - Control Académico");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6, 6, 6, 6);
        gc.anchor = GridBagConstraints.WEST;

        gc.gridx = 0; gc.gridy = 0;
        p.add(new JLabel("Usuario:"), gc);
        gc.gridx = 1;
        p.add(txtUsuario, gc);

        gc.gridx = 0; gc.gridy = 1;
        p.add(new JLabel("Contraseña:"), gc);
        gc.gridx = 1;
        p.add(txtContrasena, gc);

        gc.gridx = 1; gc.gridy = 2;
        gc.anchor = GridBagConstraints.EAST;
        p.add(btnIngresar, gc);

        add(p);
        pack();

        btnIngresar.addActionListener(e -> intentarLogin());
        getRootPane().setDefaultButton(btnIngresar);
    }

    private void intentarLogin() {
        String usuario = txtUsuario.getText().trim();
        String passPlano = new String(txtContrasena.getPassword()).trim();

        if (usuario.isEmpty() || passPlano.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Completa usuario y contraseña.");
            return;
        }

        String hash = PasswordUtil.sha256(passPlano);
        try {
            Usuario u = new UsuarioDAO().validarLogin(usuario, hash);
            if (u != null) {
                JOptionPane.showMessageDialog(this, "Bienvenido, " + u.getUsuario() + " (" + u.getRol() + ")");
                new MenuPrincipal(u).setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos.");
                txtContrasena.setText("");
                txtContrasena.requestFocusInWindow();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al validar: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Menú simple con control por rol */
    public static class MenuPrincipal extends JFrame {
        public MenuPrincipal(Usuario u) {
            setTitle("Menú - Control Académico");
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);

            JButton btnAlumnos       = new JButton("Registro Alumno");
            JButton btnCursos        = new JButton("Cursos");
            JButton btnInscripciones = new JButton("Inscripciones"); // <— nuevo
            JButton btnUsuarios      = new JButton("Gestión Usuarios");

            JPanel p = new JPanel();
            p.add(btnAlumnos);
            p.add(btnCursos);
            p.add(btnInscripciones); // <— nuevo
            p.add(btnUsuarios);
            add(p);
            pack();

            // Rutas
            btnAlumnos.addActionListener(e -> new VentanaRegistroAlumno().setVisible(true));
            btnCursos.addActionListener(e -> new VentanaCursos().setVisible(true));
            btnInscripciones.addActionListener(e -> new VentanaInscripciones().setVisible(true)); // <— nuevo

            // Mostrar/ocultar por rol
            if (!"ADMIN".equalsIgnoreCase(u.getRol())) {
                btnUsuarios.setEnabled(false); // o setVisible(false)
            } else {
                btnUsuarios.addActionListener(e -> {
                    JOptionPane.showMessageDialog(this, "TODO: Ventana de gestión de usuarios");
                });
            }
        }
    }
}


