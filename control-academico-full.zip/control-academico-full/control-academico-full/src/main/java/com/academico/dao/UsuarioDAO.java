package com.academico.dao;

import com.academico.config.ConexionDB;
import com.academico.modelo.Usuario;

import java.sql.*;

public class UsuarioDAO {

    /** Devuelve el Usuario si las credenciales son correctas; si no, null. */
    public Usuario validarLogin(String usuario, String hashClave) throws SQLException {
        String sql = "SELECT id, usuario, rol FROM usuarios WHERE usuario = ? AND hash_clave = ? LIMIT 1";
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql)) {
            ps.setString(1, usuario);
            ps.setString(2, hashClave);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Usuario(rs.getInt("id"), rs.getString("usuario"), rs.getString("rol"));
                }
            }
        }
        return null;
    }

    /** (Opcional) Crear usuario nuevo: hashClave debe venir ya en SHA-256 */
    public void registrar(String usuario, String hashClave, String rol) throws SQLException {
        String sql = "INSERT INTO usuarios (usuario, hash_clave, rol) VALUES (?, ?, ?)";
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql)) {
            ps.setString(1, usuario);
            ps.setString(2, hashClave);
            ps.setString(3, rol);
            ps.executeUpdate();
        }
    }
}
