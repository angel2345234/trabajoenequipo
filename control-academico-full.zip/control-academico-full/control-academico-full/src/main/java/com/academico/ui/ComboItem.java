package com.academico.ui;

public class ComboItem {
    private final int id;
    private final String texto;
    public ComboItem(int id, String texto) { this.id = id; this.texto = texto; }
    public int getId() { return id; }
    @Override public String toString() { return texto; }
}

