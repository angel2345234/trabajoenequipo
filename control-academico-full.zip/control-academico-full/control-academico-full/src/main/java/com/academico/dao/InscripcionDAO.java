package com.academico.dao;

import com.academico.config.ConexionDB;
import com.academico.modelo.InscripcionVista;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InscripcionDAO {

    /** Crea una inscripción. Si nota es null, se guarda NULL. */
    public void registrar(int idAlumno, int idCurso, BigDecimal nota) throws SQLException {
        String sql = "INSERT INTO inscripciones (id_alumno, id_curso, nota) VALUES (?,?,?)";
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql)) {
            ps.setInt(1, idAlumno);
            ps.setInt(2, idCurso);
            if (nota == null) ps.setNull(3, Types.DECIMAL); else ps.setBigDecimal(3, nota);
            ps.executeUpdate();
        }
    }

    /** Actualiza la nota (0–20). */
    public void actualizarNota(int idInscripcion, BigDecimal nota) throws SQLException {
        String sql = "UPDATE inscripciones SET nota=? WHERE id=?";
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql)) {
            ps.setBigDecimal(1, nota);
            ps.setInt(2, idInscripcion);
            ps.executeUpdate();
        }
    }

    /** Elimina una inscripción. */
    public void eliminar(int idInscripcion) throws SQLException {
        String sql = "DELETE FROM inscripciones WHERE id=?";
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql)) {
            ps.setInt(1, idInscripcion);
            ps.executeUpdate();
        }
    }

    /** Lista con nombres de alumno y curso. */
    public List<InscripcionVista> listarVistas() throws SQLException {
        String sql = """
                SELECT i.id, a.nombre AS alumno, c.nombre AS curso, i.nota
                FROM inscripciones i
                JOIN Alumnos a ON a.id = i.id_alumno
                JOIN Cursos  c ON c.id = i.id_curso
                ORDER BY i.id DESC
                """;
        List<InscripcionVista> lista = new ArrayList<>();
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new InscripcionVista(
                        rs.getInt("id"),
                        rs.getString("alumno"),
                        rs.getString("curso"),
                        rs.getBigDecimal("nota")
                ));
            }
        }
        return lista;
    }
}
