-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-10-2025 a las 04:26:38
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `control_academico`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

CREATE TABLE `alumnos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `contrasena` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursos`
--

CREATE TABLE `cursos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `equipos_autorizados`
--

CREATE TABLE `equipos_autorizados` (
  `mac` varchar(20) NOT NULL,
  `etiqueta` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `equipos_autorizados`
--

INSERT INTO `equipos_autorizados` (`mac`, `etiqueta`) VALUES
('14:D4:24:84:08:2B', 'Laptop Eli');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inscripciones`
--

CREATE TABLE `inscripciones` (
  `id` int(11) NOT NULL,
  `id_alumno` int(11) NOT NULL,
  `id_curso` int(11) NOT NULL,
  `nota` decimal(5,2) DEFAULT NULL,
  `fecha` date NOT NULL DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `hash_clave` char(64) NOT NULL,
  `rol` varchar(20) NOT NULL DEFAULT 'ALUMNO',
  `estado` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `hash_clave`, `rol`, `estado`) VALUES
(1, 'admin', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'ADMIN', 1),
(2, 'doc1', '481f6cc0511143ccdd7e2d1b1b94faf0a700a8b49cd13922a70b5ae28acaa8c5', 'PROFESOR', 1);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_inscripciones`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_inscripciones` (
`id` int(11)
,`alumno` varchar(80)
,`curso` varchar(100)
,`nota` decimal(5,2)
,`fecha` date
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_promedio_alumno`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_promedio_alumno` (
`id` int(11)
,`nombre` varchar(80)
,`promedio` decimal(6,2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_promedio_curso`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_promedio_curso` (
`id` int(11)
,`nombre` varchar(100)
,`promedio` decimal(6,2)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `v_inscripciones`
--
DROP TABLE IF EXISTS `v_inscripciones`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_inscripciones`  AS SELECT `i`.`id` AS `id`, `a`.`nombre` AS `alumno`, `c`.`nombre` AS `curso`, `i`.`nota` AS `nota`, `i`.`fecha` AS `fecha` FROM ((`inscripciones` `i` join `alumnos` `a` on(`a`.`id` = `i`.`id_alumno`)) join `cursos` `c` on(`c`.`id` = `i`.`id_curso`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_promedio_alumno`
--
DROP TABLE IF EXISTS `v_promedio_alumno`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_promedio_alumno`  AS SELECT `a`.`id` AS `id`, `a`.`nombre` AS `nombre`, round(avg(`i`.`nota`),2) AS `promedio` FROM (`alumnos` `a` left join `inscripciones` `i` on(`i`.`id_alumno` = `a`.`id` and `i`.`nota` is not null)) GROUP BY `a`.`id`, `a`.`nombre` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_promedio_curso`
--
DROP TABLE IF EXISTS `v_promedio_curso`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_promedio_curso`  AS SELECT `c`.`id` AS `id`, `c`.`nombre` AS `nombre`, round(avg(`i`.`nota`),2) AS `promedio` FROM (`cursos` `c` left join `inscripciones` `i` on(`i`.`id_curso` = `c`.`id` and `i`.`nota` is not null)) GROUP BY `c`.`id`, `c`.`nombre` ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `equipos_autorizados`
--
ALTER TABLE `equipos_autorizados`
  ADD PRIMARY KEY (`mac`);

--
-- Indices de la tabla `inscripciones`
--
ALTER TABLE `inscripciones`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_insc_alumno_curso` (`id_alumno`,`id_curso`),
  ADD KEY `idx_insc_alumno` (`id_alumno`),
  ADD KEY `idx_insc_curso` (`id_curso`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cursos`
--
ALTER TABLE `cursos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `inscripciones`
--
ALTER TABLE `inscripciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `inscripciones`
--
ALTER TABLE `inscripciones`
  ADD CONSTRAINT `fk_insc_alumno` FOREIGN KEY (`id_alumno`) REFERENCES `alumnos` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_insc_curso` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
