package com.academico.presentacion;

import com.academico.datos.UsuarioDAO;
import com.academico.entidad.Usuario;
import com.academico.util.PasswordUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class VentanaUsuarios extends JFrame {

    private final JTextField txtId = new JTextField(5);
    private final JTextField txtUsuario = new JTextField(16);
    private final JPasswordField txtClave = new JPasswordField(16);
    private final JComboBox<String> cbRol = new JComboBox<>(new String[]{"ADMIN","Profesor","Alumno"});
    private final JCheckBox chkActivo = new JCheckBox("Activo", true);

    private final JButton btnNuevo = new JButton("Nuevo");
    private final JButton btnGuardar = new JButton("Guardar");
    private final JButton btnActualizar = new JButton("Actualizar");
    private final JButton btnCambiarClave = new JButton("Cambiar clave");
    private final JButton btnEliminar = new JButton("Eliminar");
    private final JButton btnRefrescar = new JButton("Refrescar");

    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID","Usuario","Rol","Estado"}, 0){
        @Override public boolean isCellEditable(int r,int c){return false;}
    };
    private final JTable tabla = new JTable(model);

    public VentanaUsuarios(){
        setTitle("Gestión de Usuarios");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Form
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5,5,5,5); g.anchor = GridBagConstraints.WEST;

        int y=0;
        g.gridx=0; g.gridy=y; form.add(new JLabel("ID:"), g);
        g.gridx=1; txtId.setEditable(false); form.add(txtId, g);

        y++; g.gridx=0; g.gridy=y; form.add(new JLabel("Usuario:"), g);
        g.gridx=1; form.add(txtUsuario, g);

        y++; g.gridx=0; g.gridy=y; form.add(new JLabel("Clave (nuevo):"), g);
        g.gridx=1; form.add(txtClave, g);

        y++; g.gridx=0; g.gridy=y; form.add(new JLabel("Rol:"), g);
        g.gridx=1; form.add(cbRol, g);

        y++; g.gridx=0; g.gridy=y; form.add(new JLabel("Estado:"), g);
        g.gridx=1; form.add(chkActivo, g);

        // Botones
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT,8,8));
        actions.add(btnNuevo); actions.add(btnGuardar); actions.add(btnActualizar);
        actions.add(btnCambiarClave); actions.add(btnEliminar); actions.add(btnRefrescar);

        // Tabla
        JScrollPane sp = new JScrollPane(tabla);
        sp.setPreferredSize(new Dimension(560, 260));

        setLayout(new BorderLayout());
        add(form, BorderLayout.NORTH);
        add(actions, BorderLayout.CENTER);
        add(sp, BorderLayout.SOUTH);

        // Eventos
        btnNuevo.addActionListener(e -> limpiar());
        btnGuardar.addActionListener(e -> guardar());
        btnActualizar.addActionListener(e -> actualizar());
        btnCambiarClave.addActionListener(e -> cambiarClave());
        btnEliminar.addActionListener(e -> eliminar());
        btnRefrescar.addActionListener(e -> cargar());

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                int row = tabla.getSelectedRow();
                txtId.setText(String.valueOf(model.getValueAt(row,0)));
                txtUsuario.setText(String.valueOf(model.getValueAt(row,1)));
                cbRol.setSelectedItem(String.valueOf(model.getValueAt(row,2)));
                chkActivo.setSelected("Activo".equals(model.getValueAt(row,3)));
                txtClave.setText("");
            }
        });

        cargar();
        pack();
    }

    private void limpiar(){
        txtId.setText(""); txtUsuario.setText(""); txtClave.setText("");
        cbRol.setSelectedIndex(1); chkActivo.setSelected(true);
        tabla.clearSelection();
    }

    private void cargar(){
        model.setRowCount(0);
        try {
            List<Usuario> lista = new UsuarioDAO().listar();
            for (Usuario u : lista) {
                String estado = (u.getEstado()==1) ? "Activo" : "Inactivo";
                model.addRow(new Object[]{u.getId(), u.getUsuario(), u.getRol(), estado});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al listar: " + e.getMessage());
        }
    }

    private void guardar(){
        String usuario = txtUsuario.getText().trim();
        String clave = new String(txtClave.getPassword()).trim();
        String rol = String.valueOf(cbRol.getSelectedItem());
        int estado = chkActivo.isSelected()?1:0;

        if (usuario.isEmpty() || clave.isEmpty()){
            JOptionPane.showMessageDialog(this, "Usuario y Clave son obligatorios.");
            return;
        }
        try {
            String hash = PasswordUtil.sha256(clave);
            new UsuarioDAO().registrar(usuario, hash, rol, estado);
            JOptionPane.showMessageDialog(this, "Usuario registrado.");
            limpiar(); cargar();
        } catch (SQLException e){
            JOptionPane.showMessageDialog(this, "Error al registrar: " + e.getMessage());
        }
    }

    private void actualizar(){
        if (txtId.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Selecciona un usuario de la tabla.");
            return;
        }
        int id = Integer.parseInt(txtId.getText());
        String usuario = txtUsuario.getText().trim();
        String rol = String.valueOf(cbRol.getSelectedItem());
        int estado = chkActivo.isSelected()?1:0;

        if (usuario.isEmpty()){
            JOptionPane.showMessageDialog(this, "Usuario no puede estar vacío.");
            return;
        }
        try {
            new UsuarioDAO().actualizar(id, usuario, rol, estado);
            JOptionPane.showMessageDialog(this, "Usuario actualizado.");
            cargar();
        } catch (SQLException e){
            JOptionPane.showMessageDialog(this, "Error al actualizar: " + e.getMessage());
        }
    }

    private void cambiarClave(){
        if (txtId.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Selecciona un usuario de la tabla.");
            return;
        }
        int id = Integer.parseInt(txtId.getText());
        String nueva = JOptionPane.showInputDialog(this, "Nueva clave (se guardará en SHA-256):");
        if (nueva == null) return;
        nueva = nueva.trim();
        if (nueva.isEmpty()){
            JOptionPane.showMessageDialog(this, "Clave vacía.");
            return;
        }
        try {
            new UsuarioDAO().cambiarClave(id, PasswordUtil.sha256(nueva));
            JOptionPane.showMessageDialog(this, "Clave actualizada.");
        } catch (SQLException e){
            JOptionPane.showMessageDialog(this, "Error al cambiar clave: " + e.getMessage());
        }
    }

    private void eliminar(){
        if (txtId.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Selecciona un usuario de la tabla.");
            return;
        }
        int id = Integer.parseInt(txtId.getText());
        int r = JOptionPane.showConfirmDialog(this, "¿Eliminar usuario?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (r != JOptionPane.YES_OPTION) return;
        try {
            new UsuarioDAO().eliminar(id);
            JOptionPane.showMessageDialog(this, "Usuario eliminado.");
            limpiar(); cargar();
        } catch (SQLException e){
            JOptionPane.showMessageDialog(this, "Error al eliminar: " + e.getMessage());
        }
    }
}
