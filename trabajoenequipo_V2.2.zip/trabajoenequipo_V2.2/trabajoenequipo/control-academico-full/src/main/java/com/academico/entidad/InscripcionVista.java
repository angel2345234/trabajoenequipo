package com.academico.entidad;

import java.math.BigDecimal;

public class InscripcionVista {
    private final int id;
    private final String alumno;
    private final String curso;
    private final BigDecimal nota;

    public InscripcionVista(int id, String alumno, String curso, BigDecimal nota) {
        this.id = id; this.alumno = alumno; this.curso = curso; this.nota = nota;
    }
    public int getId() { return id; }
    public String getAlumno() { return alumno; }
    public String getCurso() { return curso; }
    public BigDecimal getNota() { return nota; }
}
