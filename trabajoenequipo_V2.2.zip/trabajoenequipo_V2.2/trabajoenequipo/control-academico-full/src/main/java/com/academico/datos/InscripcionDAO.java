package com.academico.datos;

import com.academico.entidad.InscripcionVista;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InscripcionDAO {

    public void registrar(int idAlumno, int idCurso, BigDecimal nota) throws SQLException {
        String sql = "INSERT INTO inscripciones (id_alumno, id_curso, nota) VALUES (?,?,?)";
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql)) {
            ps.setInt(1, idAlumno);
            ps.setInt(2, idCurso);
            if (nota == null) ps.setNull(3, Types.DECIMAL); else ps.setBigDecimal(3, nota);
            ps.executeUpdate();
        } catch (SQLException ex) {
            if ("23000".equals(ex.getSQLState())) {
                throw new SQLException("El alumno ya está inscrito en ese curso.", ex);
            }
            throw ex;
        }
    }

    public void inscribirConNotaTx(int idAlumno, int idCurso, BigDecimal nota) throws SQLException {
        Connection cn = ConexionDB.getInstancia().getConexion();
        boolean old = cn.getAutoCommit();
        try {
            cn.setAutoCommit(false);
            try (PreparedStatement ps = cn.prepareStatement(
                    "INSERT INTO inscripciones (id_alumno, id_curso, nota) VALUES (?,?,?)")) {
                ps.setInt(1, idAlumno);
                ps.setInt(2, idCurso);
                if (nota == null) ps.setNull(3, Types.DECIMAL); else ps.setBigDecimal(3, nota);
                ps.executeUpdate();
            }
            cn.commit();
        } catch (SQLException ex) {
            cn.rollback();
            if ("23000".equals(ex.getSQLState())) {
                throw new SQLException("El alumno ya está inscrito en ese curso.", ex);
            }
            throw ex;
        } finally {
            cn.setAutoCommit(old);
        }
    }

    public void actualizarNota(int idInscripcion, BigDecimal nota) throws SQLException {
        String sql = "UPDATE inscripciones SET nota=? WHERE id=?";
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql)) {
            ps.setBigDecimal(1, nota);
            ps.setInt(2, idInscripcion);
            ps.executeUpdate();
        }
    }

    public void eliminar(int idInscripcion) throws SQLException {
        String sql = "DELETE FROM inscripciones WHERE id=?";
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql)) {
            ps.setInt(1, idInscripcion);
            ps.executeUpdate();
        }
    }

    public List<InscripcionVista> listarVistas() throws SQLException {
        String sql = "SELECT i.id, a.nombre AS alumno, c.nombre AS curso, i.nota " +
                     "FROM inscripciones i " +
                     "JOIN Alumnos a ON a.id = i.id_alumno " +
                     "JOIN Cursos  c ON c.id = i.id_curso " +
                     "ORDER BY i.id DESC";
        List<InscripcionVista> lista = new ArrayList<>();
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new InscripcionVista(
                        rs.getInt("id"),
                        rs.getString("alumno"),
                        rs.getString("curso"),
                        rs.getBigDecimal("nota")
                ));
            }
        }
        return lista;
    }
}
