package com.academico.datos;

import com.academico.entidad.Usuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    public Usuario validarLogin(String usuario, String hashClave) throws SQLException {
        String sql = "SELECT id, usuario, rol, estado FROM usuarios WHERE usuario=? AND hash_clave=? AND estado=1 LIMIT 1";
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql)) {
            ps.setString(1, usuario);
            ps.setString(2, hashClave);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Usuario u = new Usuario(rs.getInt("id"), rs.getString("usuario"), rs.getString("rol"));
                    u.setEstado(rs.getInt("estado"));
                    return u;
                }
            }
        }
        return null;
    }

    public List<Usuario> listar() throws SQLException {
        String sql = "SELECT id, usuario, rol, estado FROM usuarios ORDER BY id DESC";
        List<Usuario> out = new ArrayList<>();
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Usuario u = new Usuario(rs.getInt("id"), rs.getString("usuario"), rs.getString("rol"));
                u.setEstado(rs.getInt("estado"));
                out.add(u);
            }
        }
        return out;
    }

    public void registrar(String usuario, String hashClave, String rol, int estado) throws SQLException {
        String sql = "INSERT INTO usuarios (usuario, hash_clave, rol, estado) VALUES (?,?,?,?)";
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql)) {
            ps.setString(1, usuario);
            ps.setString(2, hashClave);
            ps.setString(3, rol);
            ps.setInt(4, estado);
            ps.executeUpdate();
        }
    }

    public void actualizar(int id, String usuario, String rol, int estado) throws SQLException {
        String sql = "UPDATE usuarios SET usuario=?, rol=?, estado=? WHERE id=?";
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql)) {
            ps.setString(1, usuario);
            ps.setString(2, rol);
            ps.setInt(3, estado);
            ps.setInt(4, id);
            ps.executeUpdate();
        }
    }

    public void cambiarClave(int id, String hashClave) throws SQLException {
        String sql = "UPDATE usuarios SET hash_clave=? WHERE id=?";
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql)) {
            ps.setString(1, hashClave);
            ps.setInt(2, id);
            ps.executeUpdate();
        }
    }

    public void eliminar(int id) throws SQLException {
        String sql = "DELETE FROM usuarios WHERE id=?";
        try (PreparedStatement ps = ConexionDB.getInstancia().getConexion().prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
