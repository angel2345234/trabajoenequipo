package com.academico.presentacion;

import com.academico.datos.AlumnoDAO;
import com.academico.datos.CursoDAO;
import com.academico.datos.InscripcionDAO;
import com.academico.entidad.Alumno;
import com.academico.entidad.Curso;
import com.academico.entidad.InscripcionVista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class VentanaInscripciones extends JFrame {

    private final JComboBox<ComboItem> cbAlumno = new JComboBox<>();
    private final JComboBox<ComboItem> cbCurso  = new JComboBox<>();
    private final JTextField txtNota = new JTextField(6);

    private final JButton btnInscribir  = new JButton("Inscribir");
    private final JButton btnActualizar = new JButton("Actualizar nota");
    private final JButton btnEliminar   = new JButton("Eliminar");
    private final JButton btnRefrescar  = new JButton("Refrescar");

    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID","Alumno","Curso","Nota"}, 0) {
        @Override public boolean isCellEditable(int r,int c){ return false; }
    };
    private final JTable tabla = new JTable(model);

    public VentanaInscripciones() {
        setTitle("Inscripciones");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT,8,8));
        top.add(new JLabel("Alumno:")); top.add(cbAlumno);
        top.add(new JLabel("Curso:"));  top.add(cbCurso);
        top.add(new JLabel("Nota (0–20):")); top.add(txtNota);
        top.add(btnInscribir); top.add(btnActualizar); top.add(btnEliminar); top.add(btnRefrescar);

        JScrollPane sp = new JScrollPane(tabla);
        sp.setPreferredSize(new Dimension(640, 240));

        add(top, BorderLayout.NORTH);
        add(sp, BorderLayout.CENTER);

        // Eventos
        btnInscribir.addActionListener(e -> inscribir());
        btnActualizar.addActionListener(e -> actualizarNota());
        btnEliminar.addActionListener(e -> eliminar());
        btnRefrescar.addActionListener(e -> cargarTabla());

        cargarCombos();
        cargarTabla();
        pack();
    }

    private void cargarCombos() {
        cbAlumno.removeAllItems();
        cbCurso.removeAllItems();
        try {
            List<Alumno> alumnos = new AlumnoDAO().listar();
            for (Alumno a : alumnos) cbAlumno.addItem(new ComboItem(a.getId(), a.getNombre()));
            List<Curso> cursos = new CursoDAO().listar();
            for (Curso c : cursos) cbCurso.addItem(new ComboItem(c.getId(), c.getNombre()));
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar combos: " + e.getMessage());
        }
    }

    private void cargarTabla() {
        model.setRowCount(0);
        try {
            for (InscripcionVista v : new InscripcionDAO().listarVistas()) {
                model.addRow(new Object[]{
                    v.getId(), v.getAlumno(), v.getCurso(), v.getNota()==null?"":v.getNota().toString()
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al listar: " + e.getMessage());
        }
    }

    private void inscribir() {
        ComboItem a = (ComboItem) cbAlumno.getSelectedItem();
        ComboItem c = (ComboItem) cbCurso.getSelectedItem();
        if (a == null || c == null) { JOptionPane.showMessageDialog(this, "Selecciona alumno y curso."); return; }

        BigDecimal nota = null;
        String t = txtNota.getText().trim();
        if (!t.isEmpty()) {
            try {
                nota = new BigDecimal(t);
                if (nota.compareTo(BigDecimal.ZERO) < 0 || nota.compareTo(new BigDecimal("20")) > 0) {
                    JOptionPane.showMessageDialog(this, "La nota debe estar entre 0 y 20.");
                    return;
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Nota inválida.");
                return;
            }
        }

        try {
            new InscripcionDAO().inscribirConNotaTx(a.getId(), c.getId(), nota);
            JOptionPane.showMessageDialog(this, "Inscripción creada.");
            txtNota.setText(""); cargarTabla();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al inscribir: " + e.getMessage());
        }
    }

    private void actualizarNota() {
        int row = tabla.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Selecciona una inscripción."); return; }

        int id = (int) model.getValueAt(row, 0);
        String s = JOptionPane.showInputDialog(this, "Nueva nota (0–20):", model.getValueAt(row, 3));
        if (s == null) return;

        try {
            BigDecimal n = new BigDecimal(s.trim());
            if (n.compareTo(BigDecimal.ZERO) < 0 || n.compareTo(new BigDecimal("20")) > 0) {
                JOptionPane.showMessageDialog(this, "La nota debe estar entre 0 y 20.");
                return;
            }
            new InscripcionDAO().actualizarNota(id, n);
            cargarTabla();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Nota inválida.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al actualizar: " + e.getMessage());
        }
    }

    private void eliminar() {
        int row = tabla.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Selecciona una inscripción."); return; }
        int id = (int) model.getValueAt(row, 0);
        int r = JOptionPane.showConfirmDialog(this, "¿Eliminar inscripción?", "Confirmar",
                JOptionPane.YES_NO_OPTION);
        if (r != JOptionPane.YES_OPTION) return;

        try {
            new InscripcionDAO().eliminar(id);
            cargarTabla();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al eliminar: " + e.getMessage());
        }
    }
}
